<?php
  include_once('config.php');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
if($_REQUEST['sn'])
{
	$sn=$_GET['sn'];
$query="select * from btech1t where sn='$sn'";
$ck=mysqli_query($cn,$query);
$chotu=mysqli_fetch_array($ck);
$gender=$chotu['gender'];
$hobbies=$chotu['hobbies'];

$str_array = explode(",",$hobbies); 




}
if(isset($_POST['edit']))
{
   $name=$_POST['name'];
  $email=$_POST['email'];
  $gender=$_POST['gender'];

  $dir="images/";
  $pic=$dir.basename($_FILES['pic']['name']);
  move_uploaded_file($_FILES['pic']['tmp_name'],$pic);	
  
    $hob=$_POST['hob'];
  $hobi=implode(',',$hob);
  
  $query="update btech1t set name='$name',email='$email',gender='$gender',hobbies='$hobi',pic='$pic' where sn='$sn'";
  $ck=mysqli_query($cn,$query);
}
?>
<form action="" method="post" enctype="multipart/form-data">
  <table width="400" border="1" align="center">
    <tr>
      <td colspan="2"><img src="<?php echo $chotu['pic']; ?>" height="120" width="100" /><input type="file" value="<?php echo $chotu['pic']; ?>" name="pic" /></td>
    </tr>
    <tr>
      <td>name</td><td><input type="text" value="<?php echo $chotu['name']; ?>" name="name" /></td>
    </tr>
     <tr>
      <td>email</td><td><input type="text" value="<?php echo $chotu['email']; ?>" name="email" /></td>
    </tr>
     <tr>
      <td>gender</td><td><input <?php if($gender=="male"){echo "checked";}?> type="radio" value="male" name="gender"  />m<input type="radio" <?php if($gender=="female"){echo "checked";}?> value="female"  name="gender" />f</td>
    </tr>
     <tr>
      <td>hobbies</td>
      <td><input type="checkbox" <?php if(in_array("poem",$str_array)){echo "checked";} ?> value="poem" name="hob[]" /> poem 
      <input <?php if(in_array("cricket",$str_array)){echo "checked";} ?> type="checkbox" value="cricket" name="hob[]" /> 
      cricket <input type="checkbox" value="football" name="hob[]" <?php if(in_array("football",$str_array)){echo "checked";} ?> /> football</td>
    </tr>
    <tr>
     <td colspan="2"><input type="submit" name="edit" value="update" /></td>
    </tr>
  
  </table>
</form>  
</body>
</html>