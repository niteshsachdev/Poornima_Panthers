<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin</title>
</head>

<body>
   <table width="500" align="center" border="1">
     <tr>
        <th>Sr No.<th>Team name</th> <th>Team leader Name</th><th>Registration Id.</th> <th>Mobile No.</th> <th>Email Id.</th><th>Year</th> <th>Action</th>
     </tr>
     <?php
$servername="localhost";
$username="id5251823_nsn";
$password="poornimapanthers";
$dbname="id5251823_poornimapanthers";
$conn=mysqli_connect($servername,$username,$password,$dbname);
	 $query="select * from joincollege";
 $ck=mysqli_query($conn,$query);
	 $i=1;
	 while($rw=mysqli_fetch_array($ck))
	   {
		?>
       <tr>
         <td><?php echo $i ?></td>
         <td><?php echo $rw['teamname']; ?></td>
         <td><?php echo $rw['tlname']; ?></td>
         <td><?php echo $rw['registrationid']; ?></td>
         <td><?php echo $rw['mobileno']; ?></td>
         <td><?php echo $rw['emailid']; ?></td>
         <td><?php echo $rw['year']; ?></td>
         <td>
         <a href="edit.php?sn=<?php echo $sn; ?>"><button>edit</button></a>
         <a href="delete.php?sn=<?php echo $sn; ?>"><button>delete</button></a>
         </td>
       </tr> 
       <?php
	  $i++; }
	   ?>
        
   
   </table>
</body>
</html>